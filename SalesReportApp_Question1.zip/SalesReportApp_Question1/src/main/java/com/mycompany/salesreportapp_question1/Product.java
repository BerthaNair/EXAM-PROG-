/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportapp_question1;

/**
 *
 * @author Student
 */
public class Product implements IProduct {
     private final String[] productNames;   // using a 1D array
     private final int[][] sales;           // usimg a 2D array [product][month]

  public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    } 
     @Override
   public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }
        return total;
    }
     @Override
   public  double GetAverageProductSold(){
       
        int total = GetTotalProductsSold();
        int numberOfEntries = sales.length * sales[0].length;
        return (double) total / numberOfEntries;
    }
     @Override
   public String GetMostPopularProduct(){
         int maxTotal = -1;
        int mostPopularIndex = 0;

        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            for (int j = 0; j < sales[i].length; j++) {
                productTotal += sales[i][j];
            }
            if (productTotal > maxTotal) {
                maxTotal = productTotal;
                mostPopularIndex = i;
            }
        }
        // Matches the sample format: Name(total)
        return productNames[mostPopularIndex] + "(" + maxTotal + ")";
    }

    // Helper getters useful for testing / printing
     
    public String[] getProductNames() {
        return productNames;
    }

    public int[][] getSales() {
        return sales;
        
    }
   
}
