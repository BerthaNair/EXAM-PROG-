/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salesreportapp_question1;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class SalesReportApp_Question1 {

    public static void main(String[] args) {
        
    Scanner scanner = new Scanner(System.in);

        // 1D array for the product names
        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        // 2D array for sales[product][month]
        int[][] sales = new int[3][3];

        // Collect input exactly in the style shown in the sample screenshot
        for (int p = 0; p < productNames.length; p++) {
            for (int m = 0; m < 3; m++) {
                System.out.print("Enter number of sales for month " + (m + 1)
                        + " for " + productNames[p] + ": ");
                sales[p][m] = scanner.nextInt();
            }
            System.out.println(); // this creates blank line between products (matches sample layout)
        }

        //we use this to create the Product object (implements IProduct)
        Product product = new Product(productNames, sales);

        // we will create the printer and produce the report
        PrintProduct printer = new PrintProduct();
        printer.printFullReport(product);

       scanner.close();
               
    }
      
}

