/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportapp_question1;

/**
 *
 * @author Student
 */
public class PrintProduct {
    
     public void printTotalProductSales(int total) {
        System.out.println("TOTAL PRODUCT SALES: " + total);
    }

    
     //Prints the average product sales line.
     //Displays as a whole number when the value is integral (as in the sample).
     
    public void printAverageProductSales(double average) {
        if (average == Math.floor(average)) {
            System.out.println("AVERAGE PRODUCT SALES: " + (int) average);
        } else {
            System.out.println("AVERAGE PRODUCT SALES: " + average);
        }
    }

     //Prints the most popular product line.
    public void printMostPopularProduct(String mostPopular) {
        System.out.println("MOST POPULAR PRODUCT: " + mostPopular);
    }

    
    // Prints the full report header and the three required lines.
    
    public void printFullReport(IProduct product) {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("**************************************************");
        printTotalProductSales(product.GetTotalProductsSold());
        printAverageProductSales(product.GetAverageProductSold());
     printMostPopularProduct(product.GetMostPopularProduct());
       
    }
}
    
    

