/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productapp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
/**
 *
 * @author Student
 */
public class ProductApp extends JFrame {
    private JTextField txtCustomerName;
    private JComboBox <String>cmbProduct;
    private JTextField txtPrice;
    private JButton btnProcess;
    
    public ProductApp(){
        setTitle("ProductApp");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 280);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // THE MENU BAR 
        JMenuBar menuBar = new JMenuBar();
        
        
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        
      JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processSale());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearFields());
        
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
        
        //Form panel 
         JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        //Customer Name 
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("CUSTOMER NAME:"), gbc);
        gbc.gridx = 1;
        txtCustomerName = new JTextField(15);
        formPanel.add(txtCustomerName , gbc);
        
        //Select product 
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("SELECT PRODUCT:"), gbc);
        gbc.gridx = 1;
        String []products={
            "Cozy Nights Monarch",
            "Restonic Barboados",
            "Sealy Phuket"};
        
        cmbProduct = new JComboBox<>(products);
        formPanel.add(cmbProduct,gbc);
        
        //Enter price 
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("ENTER PRICE:"), gbc);
        gbc.gridx = 1;
        txtPrice = new JTextField(20);
        formPanel.add(txtPrice, gbc);
         
        //Process button 
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth=2;
        gbc.anchor= GridBagConstraints.CENTER;
        btnProcess=new JButton("PROCESS");
        btnProcess.setPreferredSize(new Dimension (180,35));
        btnProcess.addActionListener(e ->processSale());
        formPanel.add(btnProcess,gbc);
        
        add(formPanel,BorderLayout.CENTER);
       

    }
      private void processSale() {
        String customerName = txtCustomerName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();
        String priceText = txtPrice.getText().trim();

        // Basic validation
        if (customerName.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter Customer Name and Price.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid positive price.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Perform calculations using the required class
        ProductCalculations calc = new ProductCalculations(price);
        double vat = calc.GetVat();
        double commission = calc.GetCommission();
        double total = calc.GetTotal();

        // Build message
        String message = String.format(
                "Customer Name: %s%n" +
                "Product: %s%n" +
                "VAT: R %.1f%n" +
                "COMMISSION: R %.1f%n" +
                "TOTAL: R %.1f",
                customerName, product, vat, commission, total);

        // Show message dialog
        JOptionPane.showMessageDialog(this, message, "Message",
                JOptionPane.INFORMATION_MESSAGE);

        // Save to data.txt
        saveToFile(customerName, product, vat, commission, total);
    }

    private void saveToFile(String customer, String product,
                            double vat, double commission, double total) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("data.txt", true))) {
            pw.println("DATA LOG");
            pw.println("********************************");
            pw.println("Customer Name: " + customer);
            pw.println("Product: " + product);
            pw.printf("VAT: R %.1f%n", vat);
            pw.printf("COMMISSION: R %.1f%n", commission);
            pw.printf("TOTAL: R %.1f%n", total);
            pw.println("********************************");
            pw.println();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error saving to data.txt: " + e.getMessage(),
                    "File Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    private void clearFields(){
          txtCustomerName.setText("");
          txtPrice.setText("");
          cmbProduct.setSelectedIndex(0);
    }
        
        
   


    public static void main(String[] args) {
           SwingUtilities.invokeLater(() -> {
            new ProductApp().setVisible(true);
        });
      
    }
}


